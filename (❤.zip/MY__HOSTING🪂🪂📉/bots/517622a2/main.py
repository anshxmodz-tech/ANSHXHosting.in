import logging
import os
import random
import sqlite3
import string
import time
import requests
import qrcode
import telebot
from telebot import types

# ==================== LOGGING SETUP ====================
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s", level=logging.INFO
)

# ==================== CORE CONFIGURATION ====================
TOKEN = "8748789424:AAEVW3-KLCdHz10Bndia6b5oLTGyrRQ67p8"
ADMIN_ID = 8480538679
DEFAULT_UPI = "6392142874-3@ibl"

# Gateway Configuration
GATEWAY_API_KEY = "FAM_FDB370FDE9280CC515EABFF2E6C4FA4E650DFD84"

API_ENDPOINT = "https://xyzcheats.com/api/reseller_v1.php"
API_KEY_VAL = "46ccc8110f8619b35e0d329850b5e4f4"
MASTER_KEY = "a7f3e8b2c9d1f4a6b8c2d5e9f1a3b6c8"

bot = telebot.TeleBot(TOKEN)
user_cooldowns = {}


# ==================== DATABASE SETUP (ENTERPRISE V2) ====================
def init_enterprise_database():
  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()

    cursor.execute("""CREATE TABLE IF NOT EXISTS users (
                        user_id INTEGER PRIMARY KEY, 
                        name TEXT, 
                        balance INTEGER DEFAULT 0,
                        joined_date TEXT,
                        phone TEXT,
                        is_reseller INTEGER DEFAULT 0,
                        vip_tier TEXT DEFAULT 'Standard')""")

    for col, definition in [('phone', 'TEXT'), ('is_reseller', 'INTEGER DEFAULT 0'), ('vip_tier', "TEXT DEFAULT 'Standard'")]:
      try:
        cursor.execute(f"ALTER TABLE users ADD COLUMN {col} {definition}")
      except Exception:
        pass

    cursor.execute("""CREATE TABLE IF NOT EXISTS products (
                        prod_name TEXT PRIMARY KEY, 
                        pid TEXT, 
                        description TEXT,
                        is_maintenance INTEGER DEFAULT 0,
                        maintenance_msg TEXT DEFAULT '⚠️ Ye product abhi maintenance par hai. Stock aate hi notify kar diya jayega!',
                        discount_percent INTEGER DEFAULT 0)""")

    for col, definition in [('is_maintenance', 'INTEGER DEFAULT 0'), ('maintenance_msg', "TEXT DEFAULT '⚠️ Ye product abhi maintenance par hai. Stock aate hi notify kar diya jayega!'"), ('discount_percent', 'INTEGER DEFAULT 0')]:
      try:
        cursor.execute(f"ALTER TABLE products ADD COLUMN {col} {definition}")
      except Exception:
        pass

    cursor.execute("""CREATE TABLE IF NOT EXISTS plans (
                        id INTEGER PRIMARY KEY AUTOINCREMENT, 
                        prod_name TEXT, 
                        duration TEXT, 
                        price INTEGER)""")

    cursor.execute("""CREATE TABLE IF NOT EXISTS reseller_prices (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        prod_name TEXT,
                        duration TEXT,
                        price INTEGER,
                        UNIQUE(prod_name, duration))""")

    cursor.execute("""CREATE TABLE IF NOT EXISTS history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT, 
                        user_id INTEGER, 
                        details TEXT, 
                        timestamp TEXT)""")

    cursor.execute("""CREATE TABLE IF NOT EXISTS settings (
                        key TEXT PRIMARY KEY, 
                        value TEXT)""")

    cursor.execute("""CREATE TABLE IF NOT EXISTS force_channels (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        channel_username TEXT UNIQUE,
                        channel_title TEXT)""")

    cursor.execute("""CREATE TABLE IF NOT EXISTS pending_deposits (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        amount INTEGER,
                        utr TEXT UNIQUE,
                        timestamp TEXT)""")

    cursor.execute("""CREATE TABLE IF NOT EXISTS gateway_orders (
                        order_id TEXT PRIMARY KEY,
                        user_id INTEGER,
                        amount INTEGER,
                        status TEXT)""")

    cursor.execute("""CREATE TABLE IF NOT EXISTS coupons (
                        code TEXT PRIMARY KEY,
                        amount INTEGER,
                        uses_left INTEGER)""")

    cursor.execute("""CREATE TABLE IF NOT EXISTS blocked_users (
                        user_id INTEGER PRIMARY KEY)""")

    cursor.execute("""CREATE TABLE IF NOT EXISTS user_purchases (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        product_name TEXT,
                        duration TEXT,
                        license_key TEXT,
                        timestamp TEXT)""")

    cursor.execute("""CREATE TABLE IF NOT EXISTS tickets (
                        ticket_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        username TEXT,
                        message TEXT,
                        status TEXT DEFAULT 'Open',
                        timestamp TEXT)""")

    cursor.execute("""CREATE TABLE IF NOT EXISTS spin_cooldown (
                        user_id INTEGER PRIMARY KEY,
                        last_spin_date TEXT)""")

    conn.commit()

    cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('store_title', 'ANSH ELITE STORE BOT')")
    cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('upi_id', ?)", (DEFAULT_UPI,))
    cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('support_username', 'Anshxmodzyt')")
    cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('proof_channel', 'https://t.me/Anshbhaiproofs')")
    cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('maintenance_mode', 'OFF')")
    cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('reseller_info', '💼 **Wanna Become a Reseller?**\n\nApna khud ka Panel / Bot start karein bohot hi kam daamo mein! Sabhi games ki keys wholesale price par milti hain.\n\n📌 **Reseller Fee:** ₹200 (Wallet se cut hogi)\n📌 **Minimum Wallet Balance Required:** ₹1200\n\nNeeche diye gaye button par click karke Reseller banein!')")

    cursor.execute("SELECT COUNT(*) FROM force_channels")
    if cursor.fetchone()[0] == 0:
      cursor.execute("INSERT OR IGNORE INTO force_channels (channel_username, channel_title) VALUES (?, ?)", ("@Anshconfig", "Ansh Config"))
      conn.commit()

    cursor.execute("SELECT COUNT(*) FROM products")
    if cursor.fetchone()[0] == 0:
      default_prods = [
          ("BALA MOD XYZ ~ V1 FF NONROOT", "133", "Android ID Req"),
          ("BALA MOD XYZ ~ V2 FF NONROOT", "136", "Auto - No HWID"),
          ("BR MOD FF PC VERSION", "49", "PC Version Aim/Modmenu"),
          ("BR MOD FF ROOT ANDROID", "67", "Root Android Mod"),
          ("DRIPCLIENT 8BP NONROOT ANDROID", "59", "8 Ball Pool Non-Root"),
          ("DRIPCLIENT FF NONROOT APKMOD", "62", "Non-Root APK Mod"),
          ("DRIPCLIENT FF PC AIMKILL", "44", "PC Aimkill"),
          ("DRIPCLIENT FF ROOT ANDROID", "63", "Root Android Mod"),
          ("DRIPCLIENT PROXY FF NONROOT ANDROID", "91", "Proxy Non-Root"),
          ("FLUORITE IOS FF", "58", "iOS Free Fire"),
          ("FLUORITE IOS MLBB", "84", "iOS MLBB"),
          ("HAXX-CKER PRO FF NONROOT+ROOT", "64", "Haxxcker Pro API"),
          ("HG CHEATS ANDROID PROXY FF NONROOT", "123", "Proxy Non-Root"),
          ("HG CHEATS FF APKMOD NONROOT+ROOT", "65", "Root + Nonroot"),
          ("IOS CLOUD CODM", "87", "CODM iOS"),
          ("IOS FLUORITE 8 BALL POOL", "86", "iOS 8BP"),
          ("IOS IPHONE ALL GBOX CERTIFICATE", "85", "1 Year Gbox Cert"),
          ("KOS 8 BALL POOL MOD+ROOT", "138", "Auto API"),
          ("KOS 8 BALL POOL VIRTUAL", "76", "Auto API"),
          ("KOS CARROM POOL NONROOT ANDROID", "75", "Auto API"),
          ("KOS FF ROOT ANDROID", "74", "Auto API"),
          ("MIGUL IPHONE IOS FF", "69", "Basic / PRO"),
          ("PATO TEAM FF ALL ANDROID", "54", "All Colours Mix"),
          ("PRIME HOOK FF NONROOT ANDROID", "48", "Nonroot Android"),
          ("RAPID CORE FF ROOT ANDROID", "130", "Root Android"),
          ("REAPER X PRO FF ROOT ANDROID", "81", "Root Android"),
          ("SILENT CHEAT FF NONROOT APKMOD", "127", "Non-Root APK Mod"),
          ("SILENT CHEAT FF ROOT ANDROID", "128", "Brutal / Safe"),
          ("SNAKE 8 BALL POOL NONROOT ANDROID", "79", "Nonroot Android"),
          ("SNAKE CARROM POOL NONROOT ANDROID", "77", "Nonroot Android"),
          ("SNAKE SOCCER STARS NONROOT ANDROID", "78", "Nonroot Android"),
          ("XYZ CHEATS FF ROOT ANDROID", "66", "Root Android"),
      ]
      cursor.executemany("INSERT INTO products (prod_name, pid, description) VALUES (?, ?, ?)", default_prods)
      conn.commit()


init_enterprise_database()


# ==================== HELPERS ====================
def get_setting(key):
  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()
    cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
    row = cursor.fetchone()
  return row[0] if row else ""


def update_setting(key, value):
  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()
    cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
    conn.commit()


def is_user_blocked(user_id):
  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()
    cursor.execute("SELECT 1 FROM blocked_users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
  return row is not None


def get_user_balance(user_id, name="User"):
  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()
    cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    if row is None:
      cursor.execute(
          "INSERT OR REPLACE INTO users (user_id, name, balance, joined_date) VALUES (?, ?, 0, ?)",
          (user_id, name, time.strftime("%Y-%m-%d %H:%M:%S")),
      )
      conn.commit()
      balance = 0
    else:
      balance = row[0]
  return balance


def modify_balance(user_id, amount):
  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id))
    conn.commit()


def log_history(user_id, details):
  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()
    cursor.execute("INSERT INTO history (user_id, details, timestamp) VALUES (?, ?, ?)", (user_id, details, time.strftime("%Y-%m-%d %H:%M:%S")))
    conn.commit()


def check_forced_subscription(user_id):
  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()
    cursor.execute("SELECT channel_username FROM force_channels")
    channels = cursor.fetchall()

  if not channels:
    return True

  for (ch,) in channels:
    try:
      member = bot.get_chat_member(ch, user_id)
      if member.status not in ["member", "administrator", "creator"]:
        return False
    except Exception as e:
      logging.warning(f"Error checking channel membership for {ch}: {e}")
  return True


def get_user_phone(user_id):
  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()
    cursor.execute("SELECT phone FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
  return row[0] if row and row[0] else None


def is_user_reseller(user_id):
  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()
    cursor.execute("SELECT is_reseller FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
  return row[0] == 1 if row else False


def get_product_price(prod_name, duration, user_id):
  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()
    
    # Pehle normal user price nikalte hain (discount include karke)
    cursor.execute("SELECT price, discount_percent FROM plans JOIN products ON plans.prod_name = products.prod_name WHERE plans.prod_name = ? AND duration = ?", (prod_name, duration))
    row = cursor.fetchone()
    
  if not row:
    return 0
    
  base_price, discount = row[0], row[1]
  if discount > 0:
    base_price = int(base_price * (100 - discount) / 100)
    
  # Agar user reseller hai toh price adjust karenge
  if is_user_reseller(user_id):
    # Check karein agar koi custom reseller price set hai toh woh use ho, warna auto minus logic lagega
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT price FROM reseller_prices WHERE prod_name = ? AND duration = ?", (prod_name, duration))
      res_row = cursor.fetchone()
      if res_row:
        return res_row[0]

    # Automatic Logic: Balamod ke liye ₹15 aur extra kam (total ₹35 ya jo bhi aapne manga), baaki sabhi ke liye user price se ₹20 kam
    if "BALA MOD" in prod_name.upper():
      final_res_price = base_price - 15  # User price se 20 (standard) + 15 (balamod extra) = 35 kam, ya agar sirf 15 kam chahte hain toh base_price - 15 kar sakte hain
    else:
      final_res_price = base_price - 20
      
    return max(1, final_res_price) # Price negative na ho isliye max(1, ...)
    
  return base_price


# ==================== /START COMMAND & CONTACT SHARING ====================
@bot.message_handler(commands=["start"])
def handle_start(message):
  user_id = message.from_user.id
  user_name = message.from_user.first_name or "User"

  if is_user_blocked(user_id):
    bot.reply_to(message, "❌ Your account has been blocked. Contact Admin : @Anshxmodzyt")
    return

  if get_setting("maintenance_mode") == "ON" and user_id != ADMIN_ID:
    bot.reply_to(message, "🛠️ **Bot is under Maintenance Mode!**", parse_mode="Markdown")
    return

  if not check_forced_subscription(user_id):
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT channel_username, channel_title FROM force_channels")
      channels = cursor.fetchall()

    markup = types.InlineKeyboardMarkup(row_width=1)
    for ch_username, ch_title in channels:
      display_title = ch_title if ch_title else "📢 Join Channel"
      clean_username = ch_username.replace("@", "")
      markup.add(types.InlineKeyboardButton(f"📢 {display_title}", url=f"https://t.me/{clean_username}"))
    markup.add(types.InlineKeyboardButton("🔄 Verify Joined", callback_data="back_home"))
    bot.send_message(
        message.chat.id,
        "⚠️ **Please join all our official channels to access the store!**",
        parse_mode="Markdown",
        reply_markup=markup,
    )
    return

  user_phone = get_user_phone(user_id)
  if not user_phone and user_id != ADMIN_ID:
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    markup.add(types.KeyboardButton("📱 Share Verified Contact", request_contact=True))
    bot.send_message(
        message.chat.id,
        f"🛡️ Welcome to Elite Security Gateway, <b>{user_name}</b>!\n\n📱 Secure session establish karne ke liye apna contact number share karein:",
        parse_mode="HTML",
        reply_markup=markup
    )
    return

  text_args = message.text.split()
  if len(text_args) > 1 and text_args[1].startswith("ref_"):
    try:
      referrer_id = int(text_args[1].replace("ref_", ""))
      if referrer_id != user_id:
        with sqlite3.connect("ansh_store_enterprise.db") as conn:
          cursor = conn.cursor()
          cursor.execute("SELECT user_id FROM users WHERE user_id = ?", (user_id,))
          exists = cursor.fetchone()
        if not exists:
          modify_balance(referrer_id, 5)
          log_history(referrer_id, f"Earned ₹5 from premium referral user {user_id}")
    except Exception as e:
      logging.error(f"Referral error: {e}")

  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR IGNORE INTO users (user_id, name, balance, joined_date) VALUES (?, ?, 0, ?)",
        (user_id, user_name, time.strftime("%Y-%m-%d %H:%M:%S")),
    )
    conn.commit()

  send_main_menu_message(message.chat.id, user_id, user_name)


@bot.message_handler(content_types=['contact'])
def handle_contact_sharing(message):
  user_id = message.from_user.id
  user_name = message.from_user.first_name or "User"
  
  if message.contact is not None:
    phone_number = message.contact.phone_number
    
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute(
          "INSERT OR IGNORE INTO users (user_id, name, balance, joined_date, phone) VALUES (?, ?, 0, ?, ?)",
          (user_id, user_name, time.strftime("%Y-%m-%d %H:%M:%S"), phone_number),
      )
      cursor.execute("UPDATE users SET phone = ? WHERE user_id = ?", (phone_number, user_id))
      conn.commit()
    
    remove_markup = types.ReplyKeyboardRemove()
    bot.send_message(message.chat.id, "✅ Security Verification Complete!", reply_markup=remove_markup)
    send_main_menu_message(message.chat.id, user_id, user_name)


def send_main_menu_message(chat_id, user_id, user_name):
  balance = get_user_balance(user_id, user_name)
  store_title = get_setting("store_title")
  support_username = get_setting("support_username")
  proof_url = get_setting("proof_channel") or "https://t.me/Anshbhaiproofs"
  
  badge = "👑 Elite Reseller" if is_user_reseller(user_id) else "🛡️ Standard Member"

  text = (
      f"💎 <b>⚡ {store_title} ⚡</b> 💎\n━━━━━━━━━━━━━━━━━━━━━\n"
      f"👋 Welcome, <b>{user_name}</b>!\n\n"
      f"👤 <b>User ID:</b> <code>{user_id}</code>\n"
      f"🏷️ <b>Tier:</b> {badge}\n"
      f"💰 <b>Wallet Balance:</b> ₹{balance}\n"
      f"👑 <b>Owner:</b> @{support_username}\n━━━━━━━━━━━━━━━━━━━━━"
  )

  markup = types.InlineKeyboardMarkup(row_width=2)
  markup.add(
      types.InlineKeyboardButton("⚡ 🛒 Shop Keys", callback_data="shop_key"),
      types.InlineKeyboardButton("👤 My Profile", callback_data="my_profile"),
      types.InlineKeyboardButton("📦 Orders Vault", callback_data="my_orders"),
      types.InlineKeyboardButton("💳 Add Balance", callback_data="add_balance"),
      types.InlineKeyboardButton("📊 History", callback_data="all_history"),
      types.InlineKeyboardButton("🎟️ Redeem Code", callback_data="redeem_menu"),
      types.InlineKeyboardButton("💬 Support Ticket", callback_data="support_ticket"),
      types.InlineKeyboardButton("💼 Become Reseller", callback_data="wanna_reseller"),
      types.InlineKeyboardButton("📈 Live Proofs ↗", url=proof_url),
      types.InlineKeyboardButton("🎰 Daily Lucky Spin", callback_data="lucky_spin"),
      types.InlineKeyboardButton("🎁 Earn & Refer", callback_data="referral"),
  )

  if user_id == ADMIN_ID:
    markup.add(types.InlineKeyboardButton("⚙️ Admin Control Panel", callback_data="admin_panel"))

  bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=markup)


# ==================== ADVANCED SUPPORT TICKET SYSTEM ====================

@bot.message_handler(commands=["ticket"])
def command_ticket(message):
  user_id = message.from_user.id
  if is_user_blocked(user_id):
    return
  msg = bot.reply_to(message, "🎫 **Support Ticket System**\n\nKripya apni problem, bug ya query yahan detail mein likhkar bhejen. Admin team jald hi aapse contact karegi:", parse_mode="Markdown")
  bot.register_next_step_handler(msg, process_user_support_ticket)


def process_user_support_ticket(message):
  user_id = message.from_user.id
  username = message.from_user.username or "NoUsername"
  query_text = message.text

  if not query_text:
    bot.reply_to(message, "❌ Please send a valid text message for your ticket.")
    return

  timestamp = time.strftime("%Y-%m-%d %H:%M:%S")

  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO tickets (user_id, username, message, status, timestamp) VALUES (?, ?, ?, 'Open', ?)",
        (user_id, username, query_text, timestamp)
    )
    ticket_id = cursor.lastrowid
    conn.commit()

  bot.reply_to(
      message,
      f"✅ **Ticket Successfully Submitted!**\n\n📌 **Ticket ID:** `#{ticket_id}`\nAapka message admin ke paas bhej diya gaya hai. Jald hi reply milega."
  )

  admin_notification = (
      f"🎫 **NEW SUPPORT TICKET (#{ticket_id})**\n\n"
      f"👤 **User Name:** {message.from_user.first_name}\n"
      f"🔗 **Username:** @{username}\n"
      f"🆔 **User ID:** `{user_id}`\n\n"
      f"💬 **Message:**\n{query_text}\n\n"
      f"💡 *Reply karne ke liye is message par directly 'Reply' karein ya niche diye gaye format ka use karein:*\n`/reply {user_id} <aapka message>`"
  )
  try:
    bot.send_message(ADMIN_ID, admin_notification, parse_mode="Markdown")
  except Exception as e:
    logging.error(f"Failed to notify admin about ticket: {e}")


@bot.message_handler(commands=["reply"])
def handle_admin_reply_command(message):
  if message.from_user.id != ADMIN_ID:
    return
  
  args = message.text.split(maxsplit=2)
  if len(args) < 3:
    bot.reply_to(message, "❌ Invalid format!\nUse: `/reply <user_id> <message>`", parse_mode="Markdown")
    return
  
  try:
    target_user_id = int(args[1])
    reply_msg = args[2]

    bot.send_message(
        target_user_id,
        f"💬 **Support Team Response:**\n\n{reply_msg}",
        parse_mode="Markdown"
    )
    bot.reply_to(message, f"✅ Reply successfully dispatched to user `{target_user_id}`!", parse_mode="Markdown")
  except Exception as e:
    bot.reply_to(message, f"❌ Error sending reply: {e}")


@bot.message_handler(func=lambda message: message.from_user.id == ADMIN_ID and message.reply_to_message is not None)
def handle_admin_direct_reply(message):
  replied_msg = message.reply_to_message
  reply_text = replied_msg.text or replied_msg.caption or ""
  
  if "🎫 **NEW SUPPORT TICKET" in reply_text or "From: `" in reply_text or "User ID:" in reply_text:
    try:
      lines = reply_text.split("\n")
      target_user_id = None
      for line in lines:
        if "User ID:" in line or "From:" in line:
          parts = line.replace("`", "").split()
          for p in parts:
            if p.isdigit() and len(p) > 5:
              target_user_id = int(p)
              break
      
      if target_user_id:
        bot.send_message(
            target_user_id,
            f"💬 **Support Team Response:**\n\n{message.text}",
            parse_mode="Markdown"
        )
        bot.reply_to(message, f"✅ Reply successfully sent to user `{target_user_id}`!", parse_mode="Markdown")
      else:
        bot.reply_to(message, "❌ Target User ID could not be parsed from the message.")
    except Exception as e:
      bot.reply_to(message, f"❌ Error dispatching reply: {e}")


# ==================== CALLBACK QUERY CONTROLLER ====================
@bot.callback_query_handler(func=lambda call: True)
def enterprise_callback_controller(call):
  user_id = call.from_user.id

  if is_user_blocked(user_id):
    bot.answer_callback_query(call.id, "❌ Access Denied: Account Blocked!", show_alert=True)
    return

  if get_setting("maintenance_mode") == "ON" and user_id != ADMIN_ID:
    bot.answer_callback_query(call.id, "🛠️ System under scheduled maintenance!", show_alert=True)
    return

  if call.data == "shop_key":
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT prod_name, is_maintenance, discount_percent FROM products")
      prods = cursor.fetchall()

    markup = types.InlineKeyboardMarkup(row_width=1)
    for prod_name, is_maint, discount in prods:
      if is_maint == 1:
        prefix = "🔴 [MAINTAINECE] "
      elif discount > 0:
        prefix = f"🔥 [{discount}% OFF] "
      else:
        prefix = "⚡ "
      markup.add(types.InlineKeyboardButton(f"{prefix}{prod_name}", callback_data=f"prod_{prod_name}"))
    markup.add(types.InlineKeyboardButton("🔙 Main Menu", callback_data="back_home"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, "🛒 **Elite Product Catalog:**\nSelect desired module 👇", parse_mode="Markdown", reply_markup=markup)
      else:
        bot.edit_message_text(
            "🛒 **Elite Product Catalog:**\nSelect desired module 👇",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=markup,
        )
    except Exception:
      bot.send_message(call.message.chat.id, "🛒 **Elite Product Catalog:**\nSelect desired module 👇", parse_mode="Markdown", reply_markup=markup)

  elif call.data == "wanna_reseller":
    reseller_text = get_setting("reseller_info")
    
    markup = types.InlineKeyboardMarkup(row_width=1)
    if is_user_reseller(user_id):
      markup.add(types.InlineKeyboardButton("👑 Status: Active Partner", callback_data="back_home"))
    else:
      markup.add(types.InlineKeyboardButton("🚀 Initialize Partnership (Pay ₹200)", callback_data="confirm_become_reseller"))
    markup.add(types.InlineKeyboardButton("🔙 Main Menu", callback_data="back_home"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, reseller_text, parse_mode="Markdown", reply_markup=markup)
      else:
        bot.edit_message_text(reseller_text, call.message.chat.id, call.message.message_id, parse_mode="Markdown", reply_markup=markup)
    except Exception:
      bot.send_message(call.message.chat.id, reseller_text, parse_mode="Markdown", reply_markup=markup)

  elif call.data == "confirm_become_reseller":
    if is_user_reseller(user_id):
      bot.answer_callback_query(call.id, "✅ You are already an active partner!", show_alert=True)
      return

    balance = get_user_balance(user_id)
    required_min = 1200
    reseller_fee = 200

    if balance < required_min:
      shortage = required_min - balance
      text = (
          f"❌ **REQUISITE BALANCE UNMET**\n\n"
          f"📌 Partnership activation requires a minimum balance threshold of **₹{required_min}**.\n"
          f"👤 Your Current Balance: **₹{balance}**\n"
          f"⚠️ Required Shortage Topup: **₹{shortage}**"
      )
      markup = types.InlineKeyboardMarkup()
      markup.add(types.InlineKeyboardButton("💳 Instant Top-up", callback_data="add_balance"))
      markup.add(types.InlineKeyboardButton("🔙 Back", callback_data="wanna_reseller"))
      
      try:
        if call.message.content_type == 'photo':
          bot.delete_message(call.message.chat.id, call.message.message_id)
          bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=markup)
        else:
          bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="Markdown", reply_markup=markup)
      except Exception:
        bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=markup)
      return

    modify_balance(user_id, -reseller_fee)
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("UPDATE users SET is_reseller = 1 WHERE user_id = ?", (user_id,))
      conn.commit()

    log_history(user_id, f"Invested ₹{reseller_fee} for Reseller Tier status.")

    success_text = (
        f"🎉 **PARTNERSHIP GRANTED!**\n\n"
        f"✅ You have been upgraded to **Elite Reseller Status**.\n"
        f"💸 Fee of ₹{reseller_fee} successfully processed.\n\n"
        f"Enjoy discounted wholesale pricing on all module inventory!"
    )
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("⚡ Explore Wholesale Catalog", callback_data="shop_key"))
    markup.add(types.InlineKeyboardButton("🔙 Main Menu", callback_data="back_home"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, success_text, parse_mode="Markdown", reply_markup=markup)
      else:
        bot.edit_message_text(success_text, call.message.chat.id, call.message.message_id, parse_mode="Markdown", reply_markup=markup)
    except Exception:
      bot.send_message(call.message.chat.id, success_text, parse_mode="Markdown", reply_markup=markup)

  elif call.data.startswith("prod_"):
    prod_name = call.data.replace("prod_", "")
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT description, is_maintenance, maintenance_msg FROM products WHERE prod_name = ?", (prod_name,))
      prod_row = cursor.fetchone()

    if not prod_row:
      bot.answer_callback_query(call.id, "❌ Target module not found.", show_alert=True)
      return

    desc, is_maint, maint_msg = prod_row

    if is_maint == 1:
      text = f"🛠️ **SYSTEM MODULE OFFLINE**\n\n📦 **{prod_name}**\n{maint_msg}"
      markup = types.InlineKeyboardMarkup(row_width=1)
      markup.add(types.InlineKeyboardButton("🔔 Enable Stock Alert", callback_data=f"notify_me_{prod_name}"))
      markup.add(types.InlineKeyboardButton("🔙 Back to Catalog", callback_data="shop_key"))
      
      try:
        if call.message.content_type == 'photo':
          bot.delete_message(call.message.chat.id, call.message.message_id)
          bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=markup)
        else:
          bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="Markdown", reply_markup=markup)
      except Exception:
        bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=markup)
      return

    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT duration FROM plans WHERE prod_name = ?", (prod_name,))
      plans = cursor.fetchall()

    text = f"📦 <b>{prod_name}</b>\n💎 <i>{desc}</i>\n\n⏱️ <b>Select License Duration:</b>"
    markup = types.InlineKeyboardMarkup(row_width=1)
    if plans:
      for (duration,) in plans:
        final_price = get_product_price(prod_name, duration, user_id)
        markup.add(
            types.InlineKeyboardButton(
                f"🕒 {duration} ➔ ₹{final_price}",
                callback_data=f"buyplan_{prod_name}_{duration}_{final_price}",
            )
        )
    else:
      markup.add(types.InlineKeyboardButton("⚠️ Plans Temporarily Unavailable", callback_data="shop_key"))

    markup.add(types.InlineKeyboardButton("🔙 Back", callback_data="shop_key"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)
      else:
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode="HTML",
            reply_markup=markup,
        )
    except Exception:
      bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)

  elif call.data.startswith("notify_me_"):
    prod_name = call.data.replace("notify_me_", "")
    bot.answer_callback_query(call.id, f"✅ Alert registered for '{prod_name}'.", show_alert=True)

  elif call.data.startswith("buyplan_"):
    data_stripped = call.data.replace("buyplan_", "")
    parts = data_stripped.split("_")
    price = int(parts[-1])
    duration = parts[-2]
    prod_name = "_".join(parts[:-2])

    balance = get_user_balance(user_id)

    if balance >= price:
      text = (
          f"🛒 <b>Confirm Acquisition</b>\n\n"
          f"📦 Module: <b>{prod_name}</b>\n"
          f"⏱️ Duration: <b>{duration}</b>\n"
          f"💰 Investment: <b>₹{price}</b>\n\n"
          f"✅ Sufficient balance verified in secure wallet."
      )
      markup = types.InlineKeyboardMarkup()
      markup.add(
          types.InlineKeyboardButton(
              f"⚡ Authorize Transaction (₹{price})",
              callback_data=f"confirm_{prod_name}_{duration}_{price}",
          )
      )
      markup.add(types.InlineKeyboardButton("🔙 Back", callback_data=f"prod_{prod_name}"))
      
      try:
        if call.message.content_type == 'photo':
          bot.delete_message(call.message.chat.id, call.message.message_id)
          bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)
        else:
          bot.edit_message_text(
              text,
              call.message.chat.id,
              call.message.message_id,
              parse_mode="HTML",
              reply_markup=markup,
          )
      except Exception:
        bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)
    else:
      shortage = price - balance
      text = (
          f"❌ <b>INSUFFICIENT WALLET BALANCE</b>\n\n"
          f"📦 Module: <b>{prod_name} ({duration})</b>\n"
          f"💰 Cost: <b>₹{price}</b> | Balance: <b>₹{balance}</b>\n"
          f"⚠️ Shortfall: <b>₹{shortage}</b>"
      )
      markup = types.InlineKeyboardMarkup()
      markup.add(
          types.InlineKeyboardButton(
              f"💳 Express QR Topup (₹{shortage})",
              callback_data=f"gateway_pay_{shortage}",
          )
      )
      markup.add(types.InlineKeyboardButton("🔙 Back", callback_data=f"prod_{prod_name}"))
      
      try:
        if call.message.content_type == 'photo':
          bot.delete_message(call.message.chat.id, call.message.message_id)
          bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)
        else:
          bot.edit_message_text(
              text,
              call.message.chat.id,
              call.message.message_id,
              parse_mode="HTML",
              reply_markup=markup,
          )
      except Exception:
        bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)

  elif call.data == "add_balance":
    text = (
        "💳 **Elite Automated Deposit Portal**\n\n"
        "Select your preferred top-up amount or specify a custom ledger amount for instant QR generation."
    )
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("➕ ₹50", callback_data="gateway_pay_50"),
        types.InlineKeyboardButton("➕ ₹100", callback_data="gateway_pay_100"),
        types.InlineKeyboardButton("➕ ₹200", callback_data="gateway_pay_200"),
        types.InlineKeyboardButton("➕ ₹500", callback_data="gateway_pay_500"),
    )
    markup.add(types.InlineKeyboardButton("✍️ Specify Custom Amount", callback_data="custom_deposit_prompt"))
    markup.add(types.InlineKeyboardButton("🔙 Main Menu", callback_data="back_home"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=markup)
      else:
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=markup,
        )
    except Exception:
      bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=markup)

  elif call.data == "custom_deposit_prompt":
    msg = bot.send_message(
        call.message.chat.id,
        "✍️ **Enter Top-up Amount (INR):**\nSend only numeric values (e.g., `250`):",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(msg, process_custom_gateway_amount)

  elif call.data.startswith("gateway_pay_"):
    amount = int(call.data.replace("gateway_pay_", ""))
    api_url = f"https://fampaygateway.site/api/create_order.php?amount={amount}&api_key={GATEWAY_API_KEY}"
    
    try:
      response = requests.get(api_url, timeout=10)
      res_data = response.json()
      
      if res_data.get("status") == "success":
        data = res_data["data"]
        order_id = data["order_id"]
        qr_url = data["qr_url"]
        upi_id = data["upi_id"]
        
        with sqlite3.connect("ansh_store_enterprise.db") as conn:
          cursor = conn.cursor()
          cursor.execute("INSERT OR REPLACE INTO gateway_orders (order_id, user_id, amount, status) VALUES (?, ?, ?, ?)", 
                         (order_id, user_id, amount, "PENDING"))
          conn.commit()
        
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(types.InlineKeyboardButton("🔄 Verify Payment Status", callback_data=f"gwcheck_{order_id}"))
        markup.add(types.InlineKeyboardButton("🔙 Main Menu", callback_data="back_home"))
        
        try:
          bot.delete_message(call.message.chat.id, call.message.message_id)
        except Exception:
          pass
          
        caption = (
            f"🛒 **Secure Payment Gateway v2**\n\n"
            f"🆔 **Order ID:** `{order_id}`\n"
            f"💰 **Amount Due:** ₹{amount}\n"
            f"⚡ **UPI Handle:** `{upi_id}`\n\n"
            f"📱 Scan QR or transfer via UPI app. Once finished, click **'Verify Payment Status'**."
        )
        bot.send_photo(call.message.chat.id, photo=qr_url, caption=caption, parse_mode="Markdown", reply_markup=markup)
      else:
        bot.answer_callback_query(call.id, "❌ Gateway Error: Order creation rejected.", show_alert=True)
    except Exception as e:
      logging.error(f"Gateway Create Error: {e}")
      bot.answer_callback_query(call.id, "⚠️ Network error communicating with Gateway API.", show_alert=True)

  elif call.data.startswith("gwcheck_"):
    order_id = call.data.replace("gwcheck_", "")
    
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT status, amount FROM gateway_orders WHERE order_id = ? AND user_id = ?", (order_id, user_id))
      row = cursor.fetchone()
    
    if not row:
      bot.answer_callback_query(call.id, "❌ Order signature mismatch.", show_alert=True)
      return
      
    status, amount = row
    if status == "PAID":
      bot.answer_callback_query(call.id, "✅ Order already settled.", show_alert=True)
      return
      
    verify_url = f"https://fampaygateway.site/api/verify.php?order_id={order_id}&api_key={GATEWAY_API_KEY}"
    
    try:
      response = requests.get(verify_url, timeout=10)
      res_data = response.json()
      
      if res_data.get("status") == "success":
        payment_data = res_data["data"]
        utr = payment_data.get("utr")
        
        if utr:
          with sqlite3.connect("ansh_store_enterprise.db") as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE gateway_orders SET status = 'PAID' WHERE order_id = ?", (order_id,))
            conn.commit()
          
          modify_balance(user_id, amount)
          log_history(user_id, f"Credited ₹{amount} via Secure Gateway (UTR: {utr})")
          
          bot.answer_callback_query(call.id, "🎉 Settlement Verified Successfully!", show_alert=True)
          
          success_msg = (
              f"✅ **Ledger Balance Updated!**\n\n"
              f"🆔 **Order ID:** `{order_id}`\n"
              f"💰 **Credited:** ₹{amount}\n"
              f"🔖 **UTR Reference:** `{utr}`\n"
              f"🕒 **Timestamp:** {payment_data.get('payment_time')}"
          )
          markup = types.InlineKeyboardMarkup()
          markup.add(types.InlineKeyboardButton("🔙 Main Menu", callback_data="back_home"))
          bot.edit_message_caption(chat_id=call.message.chat.id, message_id=call.message.message_id, caption=success_msg, parse_mode="Markdown", reply_markup=markup)
          return
          
      bot.answer_callback_query(call.id, "⏳ Transaction pending clearance. Complete payment first.", show_alert=True)
    except Exception as e:
      logging.error(f"Gateway Verify Error: {e}")
      bot.answer_callback_query(call.id, "⚠️ Verification check timeout.", show_alert=True)

  elif call.data.startswith("confirm_"):
    data_stripped = call.data.replace("confirm_", "")
    parts = data_stripped.split("_")
    price = int(parts[-1])
    duration = parts[-2]
    prod_name = "_".join(parts[:-2])

    balance = get_user_balance(user_id)

    if balance >= price:
      modify_balance(user_id, -price)

      with sqlite3.connect("ansh_store_enterprise.db") as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT pid FROM products WHERE prod_name = ?", (prod_name,))
        row = cursor.fetchone()

      exact_pid = row[0] if row else "66"

      headers = {
          "Content-Type": "application/x-www-form-urlencoded",
          "x-master-key": MASTER_KEY,
      }
      payload = {
          "api_key": API_KEY_VAL,
          "action": "buy",
          "product_id": exact_pid,
          "duration": duration,
          "android_id": "0b9b969bc2e7997b",
      }

      license_key = None
      api_failed = False
      try:
        api_response = requests.post(API_ENDPOINT, data=payload, headers=headers, timeout=15)
        res_data = api_response.json()
        if isinstance(res_data, dict):
          license_key = res_data.get("key") or res_data.get("license") or res_data.get("msg")
        if not license_key or "error" in str(res_data).lower():
          api_failed = True
          license_key = str(api_response.text)
      except Exception as e:
        logging.error(f"API Purchase Error: {e}")
        api_failed = True

      if api_failed:
        modify_balance(user_id, price)  
        log_history(user_id, f"Auto-refunded ₹{price} due to external provider socket error.")
        
        error_text = (
            f"❌ <b>Upstream Provider Exception!</b>\n\n"
            f"📦 Module: <b>{prod_name} ({duration})</b>\n"
            f"⚠️ External key generation endpoint unresponsive.\n"
            f"💰 Your investment of ₹{price} has been **automatically fully refunded**."
        )
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔙 Main Menu", callback_data="back_home"))
        
        try:
          if call.message.content_type == 'photo':
            bot.delete_message(call.message.chat.id, call.message.message_id)
            bot.send_message(call.message.chat.id, error_text, parse_mode="HTML", reply_markup=markup)
          else:
            bot.edit_message_text(error_text, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=markup)
        except Exception:
          bot.send_message(call.message.chat.id, error_text, parse_mode="HTML", reply_markup=markup)
        return

      with sqlite3.connect("ansh_store_enterprise.db") as conn:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO user_purchases (user_id, product_name, duration, license_key, timestamp) VALUES (?, ?, ?, ?, ?)",
            (user_id, prod_name, duration, license_key, time.strftime("%Y-%m-%d %H:%M:%S")),
        )
        conn.commit()

      log_history(user_id, f"Acquired license for {prod_name} ({duration}) at ₹{price}")

      success_text = (
          f"🎉 <b>Acquisition Successful!</b>\n\n"
          f"📦 Module: <b>{prod_name} ({duration})</b>\n"
          f"🔑 <b>License Key:</b> <code>{license_key}</code>\n\n"
          f"✨ <i>Encrypted & stored permanently in your Orders Vault.</i>"
      )
      markup = types.InlineKeyboardMarkup()
      markup.add(types.InlineKeyboardButton("🔙 Main Menu", callback_data="back_home"))
      
      try:
        if call.message.content_type == 'photo':
          bot.delete_message(call.message.chat.id, call.message.message_id)
          bot.send_message(call.message.chat.id, success_text, parse_mode="HTML", reply_markup=markup)
        else:
          bot.edit_message_text(
              success_text,
              call.message.chat.id,
              call.message.message_id,
              parse_mode="HTML",
              reply_markup=markup,
          )
      except Exception:
        bot.send_message(call.message.chat.id, success_text, parse_mode="HTML", reply_markup=markup)
    else:
      bot.answer_callback_query(call.id, "❌ Balance criteria not met.", show_alert=True)

  elif call.data == "my_profile":
    balance = get_user_balance(user_id)
    phone_no = get_user_phone(user_id) or "Secured / Private"
    reseller_badge = "Active Elite Partner 👑" if is_user_reseller(user_id) else "Standard Tier 🛡️"
    text = (
        f"👤 <b>Elite Account Dossier</b>\n━━━━━━━━━━━━━━━━━━━━━\n"
        f"🆔 <b>Telegram ID:</b> <code>{user_id}</code>\n"
        f"📱 <b>Contact:</b> {phone_no}\n"
        f"💼 <b>Partnership Status:</b> {reseller_badge}\n"
        f"💰 <b>Liquid Balance:</b> ₹{balance}\n━━━━━━━━━━━━━━━━━━━━━"
    )
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 Back", callback_data="back_home"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)
      else:
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode="HTML",
            reply_markup=markup,
        )
    except Exception:
      bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)

  elif call.data == "my_orders":
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute(
          "SELECT product_name, duration, license_key, timestamp FROM user_purchases WHERE user_id = ? ORDER BY id DESC LIMIT 10",
          (user_id,),
      )
      rows = cursor.fetchall()

    text = "📦 <b>Secure Orders Vault Archive:</b>\n\n"
    if not rows:
      text += "No records discovered in your vault history."
    else:
      for r in rows:
        text += f"• <b>{r[0]} ({r[1]})</b>\n  🔑 <code>{r[2]}</code>\n  🕒 <i>{r[3]}</i>\n\n"

    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 Back", callback_data="back_home"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)
      else:
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode="HTML",
            reply_markup=markup,
        )
    except Exception:
      bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)

  elif call.data == "all_history":
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT details, timestamp FROM history WHERE user_id = ? ORDER BY id DESC LIMIT 10", (user_id,))
      rows = cursor.fetchall()

    history_text = "📊 <b>Activity Ledger History:</b>\n\n"
    if not rows:
      history_text += "Ledger is currently empty."
    else:
      for r in rows:
        history_text += f"• {r[0]} <i>({r[1]})</i>\n"

    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 Back", callback_data="back_home"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, history_text, parse_mode="HTML", reply_markup=markup)
      else:
        bot.edit_message_text(
            history_text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode="HTML",
            reply_markup=markup,
        )
    except Exception:
      bot.send_message(call.message.chat.id, history_text, parse_mode="HTML", reply_markup=markup)

  elif call.data == "redeem_menu":
    msg = bot.send_message(call.message.chat.id, "🎟️ Submit your **Promotional Code Token**:", parse_mode="Markdown")
    bot.register_next_step_handler(msg, process_user_redeem_coupon)

  elif call.data == "support_ticket":
    msg = bot.send_message(call.message.chat.id, "🎫 **Support Ticket System**\n\nKripya apni problem ya query yahan detail mein likhkar bhejen:")
    bot.register_next_step_handler(msg, process_user_support_ticket)

  elif call.data == "lucky_spin":
    current_date = time.strftime("%Y-%m-%d")
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT last_spin_date FROM spin_cooldown WHERE user_id = ?", (user_id,))
      row = cursor.fetchone()

    if row and row[0] == current_date:
      bot.answer_callback_query(call.id, "❌ Daily spin allocation already claimed today!", show_alert=True)
      return

    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("INSERT OR REPLACE INTO spin_cooldown (user_id, last_spin_date) VALUES (?, ?)", (user_id, current_date))
      conn.commit()

    bot.answer_callback_query(call.id, "🎰 Spinning Wheel Matrix...")
    reward = random.choice([0, 1, 2, 3, 5, 10, 15])

    if reward > 0:
      modify_balance(user_id, reward)
      log_history(user_id, f"Lucky Spin Reward: Won ₹{reward}")
      bot.send_message(call.message.chat.id, f"🎰 **Elite Lucky Spin Matrix:**\n\n🎉 Winner! **₹{reward}** credited directly to wallet balance.", parse_mode="Markdown")
    else:
      bot.send_message(call.message.chat.id, "🎰 **Elite Lucky Spin Matrix:**\n\n😢 No reward secured on this spin. Try again tomorrow.", parse_mode="Markdown")

  elif call.data == "referral":
    bot.answer_callback_query(call.id, "Generating link...")
    bot.send_message(
        call.message.chat.id,
        f"🎁 **Exclusive Referral Link:**\n`https://t.me/AK_paid_shop_bot?start=ref_{user_id}`\n\nInvite peers & accumulate ₹5 per onboarding milestone!",
        parse_mode="Markdown",
    )

  elif call.data == "admin_panel":
    if user_id != ADMIN_ID:
      return
    m_status = get_setting("maintenance_mode")
    text = f"⚙️ <b>ADMINISTRATION COMMAND CENTER</b>\n━━━━━━━━━━━━━━━━━━━━━\n🛠️ Maintenance Toggle: <b>{m_status}</b>"
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("👥 User Matrix", callback_data="adm_users_list"),
        types.InlineKeyboardButton("👑 Reseller Analytics", callback_data="adm_reseller_list"),
        types.InlineKeyboardButton("📦 Vault Orders", callback_data="adm_all_orders"),
        types.InlineKeyboardButton("💳 Payment Logs", callback_data="adm_deposit_history"),
        types.InlineKeyboardButton("📊 System Analytics", callback_data="adm_stats"),
        types.InlineKeyboardButton("🔍 User Lookup", callback_data="adm_lookup_prompt"),
        types.InlineKeyboardButton("🚫 Sanction / Ban", callback_data="adm_ban_menu"),
        types.InlineKeyboardButton("📢 Force Channels", callback_data="adm_force_channels"),
        types.InlineKeyboardButton("🛠️ Product Status", callback_data="adm_maint_manager"),
        types.InlineKeyboardButton("💼 Edit Reseller Info", callback_data="adm_edit_reseller"),
        types.InlineKeyboardButton("💰 Reseller Pricing", callback_data="adm_edit_reseller_price"),
        types.InlineKeyboardButton("🎟️ Generate Coupon", callback_data="adm_create_coupon"),
        types.InlineKeyboardButton("➕ Add Product", callback_data="adm_add_p"),
        types.InlineKeyboardButton("❌ Remove Product", callback_data="adm_edit_del_p"),
        types.InlineKeyboardButton("➕ Add Plan", callback_data="adm_add_plan"),
        types.InlineKeyboardButton("🗑️ Remove Plan", callback_data="adm_del_plan"),
        types.InlineKeyboardButton("💰 Credit Balance", callback_data="adm_give"),
        types.InlineKeyboardButton("📂 Secure DB Backup", callback_data="adm_backup_db"),
        types.InlineKeyboardButton("🛠️ Toggle Maintenance", callback_data="adm_toggle_maint"),
        types.InlineKeyboardButton("📢 Elite Broadcast", callback_data="adm_broadcast"),
        types.InlineKeyboardButton("🔙 Main Menu", callback_data="back_home"),
    )
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)
      else:
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode="HTML",
            reply_markup=markup,
        )
    except Exception:
      bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)

  elif call.data == "adm_reseller_list":
    if user_id != ADMIN_ID:
      return
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT user_id, name, balance, phone FROM users WHERE is_reseller = 1")
      resellers = cursor.fetchall()
      
      today_date = time.strftime("%Y-%m-%d")
      
      text = "👑 **PARTNER RESELLER ANALYTICS & CONTACTS**\n\n"
      if not resellers:
        text += "No active reseller accounts registered."
      else:
        for r in resellers:
          r_id, r_name, r_bal, r_phone = r
          phone_str = f"<code>{r_phone}</code>" if r_phone else "Private"
          
          cursor.execute("SELECT COUNT(*) FROM user_purchases WHERE user_id = ? AND timestamp LIKE ?", (r_id, f"{today_date}%"))
          today_keys = cursor.fetchone()[0]
          
          cursor.execute("SELECT COUNT(*) FROM user_purchases WHERE user_id = ?", (r_id,))
          total_keys = cursor.fetchone()[0]
          
          text += (
              f"👤 **Name:** {r_name}\n"
              f"🆔 **ID:** `{r_id}` | 📱 **Mobile No:** {phone_str}\n"
              f"💰 **Balance:** ₹{r_bal}\n"
              f"🔥 **Keys Today:** `{today_keys}` | 📦 **Lifetime:** `{total_keys}`\n"
              f"━━━━━━━━━━━━━━━━━━━━━\n"
          )
    
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 Back to Admin", callback_data="admin_panel"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=markup)
      else:
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="Markdown", reply_markup=markup)
    except Exception:
      bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=markup)

  elif call.data == "adm_edit_reseller":
    if user_id != ADMIN_ID:
      return
    msg = bot.send_message(call.message.chat.id, "💼 **Send updated Reseller info text markdown:**", parse_mode="Markdown")
    bot.register_next_step_handler(msg, process_admin_save_reseller_text)

  elif call.data == "adm_edit_reseller_price":
    if user_id != ADMIN_ID:
      return
    msg = bot.send_message(
        call.message.chat.id,
        "💰 **Configure Reseller Price Tier:**\nFormat: `Product Name | Duration | Price`",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(msg, process_admin_save_reseller_price)

  elif call.data == "adm_maint_manager":
    if user_id != ADMIN_ID:
      return
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT prod_name, is_maintenance FROM products")
      prods = cursor.fetchall()

    text = "🛠️ **Module Maintenance Manager**\n\nSelect module to toggle operational state:"
    markup = types.InlineKeyboardMarkup(row_width=1)
    for p_name, is_maint in prods:
      status_icon = "🔴 [MAINTENANCE]" if is_maint == 1 else "🟢 [OPERATIONAL]"
      markup.add(types.InlineKeyboardButton(f"{status_icon} {p_name}", callback_data=f"adm_toggle_p_{p_name}"))
    markup.add(types.InlineKeyboardButton("🔙 Admin Panel", callback_data="admin_panel"))

    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=markup)
      else:
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="Markdown", reply_markup=markup)
    except Exception:
      bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=markup)

  elif call.data.startswith("adm_toggle_p_"):
    if user_id != ADMIN_ID:
      return
    prod_name = call.data.replace("adm_toggle_p_", "")
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT is_maintenance FROM products WHERE prod_name = ?", (prod_name,))
      row = cursor.fetchone()
      if row:
        new_status = 0 if row[0] == 1 else 1
        cursor.execute("UPDATE products SET is_maintenance = ? WHERE prod_name = ?", (new_status, prod_name))
        conn.commit()
    
    bot.answer_callback_query(call.id, f"✅ State updated for '{prod_name}'", show_alert=True)
    call.data = "adm_maint_manager"
    enterprise_callback_controller(call)

  elif call.data == "adm_all_orders":
    if user_id != ADMIN_ID:
      return
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT user_id, product_name, duration, license_key, timestamp FROM user_purchases ORDER BY id DESC LIMIT 20")
      orders = cursor.fetchall()

    text = "📦 **Global Vault Acquisition Log:**\n\n"
    if not orders:
      text += "No records found."
    else:
      for o in orders:
        text += f"👤 User: `{o[0]}` | 📦 **{o[1]} ({o[2]})**\n🔑 Key: `<code>{o[3]}</code>`\n🕒 _{o[4]}_\n\n"

    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 Back to Admin", callback_data="admin_panel"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=markup)
      else:
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="Markdown", reply_markup=markup)
    except Exception:
      bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=markup)

  elif call.data == "adm_deposit_history":
    if user_id != ADMIN_ID:
      return
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT order_id, user_id, amount, status FROM gateway_orders ORDER BY order_id DESC LIMIT 20")
      deposits = cursor.fetchall()

    text = "💳 **Gateway Deposit Ledgers:**\n\n"
    if not deposits:
      text += "No payment orders logged."
    else:
      for d in deposits:
        status_emoji = "✅" if d[3] == "PAID" else "⏳"
        text += f"{status_emoji} ID: `{d[0]}` | User: `{d[1]}` | ₹{d[2]} | **{d[3]}**\n"

    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 Back to Admin", callback_data="admin_panel"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=markup)
      else:
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="Markdown", reply_markup=markup)
    except Exception:
      bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=markup)

  elif call.data == "adm_stats":
    if user_id != ADMIN_ID:
      return
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT COUNT(*) FROM users")
      total_users = cursor.fetchone()[0]
      cursor.execute("SELECT COUNT(*) FROM user_purchases")
      total_orders = cursor.fetchone()[0]
      cursor.execute("SELECT COUNT(*) FROM products")
      total_prods = cursor.fetchone()[0]

    text = (
        f"📊 <b>SYSTEM ANALYTICS REPORT</b>\n━━━━━━━━━━━━━━━━━━━━━\n"
        f"👥 Total Registered Users: <code>{total_users}</code>\n"
        f"📦 Total Fulfilled Orders: <code>{total_orders}</code>\n"
        f"🛒 Available Modules: <code>{total_prods}</code>"
    )
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 Back to Admin", callback_data="admin_panel"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)
      else:
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=markup)
    except Exception:
      bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)

  elif call.data == "adm_lookup_prompt":
    if user_id != ADMIN_ID:
      return
    msg = bot.send_message(call.message.chat.id, "🔍 Input target User ID for deep database lookup:", parse_mode="Markdown")
    bot.register_next_step_handler(msg, process_admin_lookup_user)

  elif call.data == "adm_force_channels":
    if user_id != ADMIN_ID:
      return
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT id, channel_username, channel_title FROM force_channels")
      channels = cursor.fetchall()

    text = "📢 <b>Configured Force Channels:</b>\n\n"
    if not channels:
      text += "No restriction channels."
    else:
      for ch_id, ch_uname, ch_title in channels:
        text += f"🆔 ID: {ch_id} | 🏷️ {ch_title} | 🔗 `<code>{ch_uname}</code>`\n"

    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("➕ Link Channel", callback_data="adm_add_fchannel"),
        types.InlineKeyboardButton("❌ Unlink Channel", callback_data="adm_del_fchannel_menu"),
    )
    markup.add(types.InlineKeyboardButton("🔙 Admin Panel", callback_data="admin_panel"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)
      else:
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=markup)
    except Exception:
      bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)

  elif call.data == "adm_add_fchannel":
    if user_id != ADMIN_ID:
      return
    msg = bot.send_message(call.message.chat.id, "➕ Format: `@ChannelUsername | Channel Title`", parse_mode="Markdown")
    bot.register_next_step_handler(msg, process_admin_add_force_channel)

  elif call.data == "adm_del_fchannel_menu":
    if user_id != ADMIN_ID:
      return
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT id, channel_username, channel_title FROM force_channels")
      channels = cursor.fetchall()

    markup = types.InlineKeyboardMarkup(row_width=1)
    for ch_id, ch_uname, ch_title in channels:
      markup.add(types.InlineKeyboardButton(f"❌ Remove {ch_title}", callback_data=f"adm_delfch_{ch_id}"))
    markup.add(types.InlineKeyboardButton("🔙 Back", callback_data="adm_force_channels"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, "Select channel to unlink:", reply_markup=markup)
      else:
        bot.edit_message_text("Select channel to unlink:", call.message.chat.id, call.message.message_id, reply_markup=markup)
    except Exception:
      bot.send_message(call.message.chat.id, "Select channel to unlink:", reply_markup=markup)

  elif call.data.startswith("adm_delfch_"):
    if user_id != ADMIN_ID:
      return
    ch_id = call.data.replace("adm_delfch_", "")
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("DELETE FROM force_channels WHERE id = ?", (ch_id,))
      conn.commit()
    bot.answer_callback_query(call.id, "✅ Channel unlinked.", show_alert=True)
    call.data = "adm_force_channels"
    enterprise_callback_controller(call)

  elif call.data == "adm_toggle_maint":
    if user_id != ADMIN_ID:
      return
    current = get_setting("maintenance_mode")
    new_val = "OFF" if current == "ON" else "ON"
    update_setting("maintenance_mode", new_val)
    bot.answer_callback_query(call.id, f"Maintenance status: {new_val}", show_alert=True)
    enterprise_callback_controller(call)

  elif call.data == "adm_backup_db":
    if user_id != ADMIN_ID:
      return
    try:
      with open("ansh_store_enterprise.db", "rb") as f:
        bot.send_document(ADMIN_ID, f, caption="📂 Secure Enterprise Database Backup Archive")
    except Exception as e:
      bot.answer_callback_query(call.id, f"Backup error: {e}")

  elif call.data == "adm_users_list":
    if user_id != ADMIN_ID:
      return
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT user_id, name, balance, phone, is_reseller FROM users")
      rows = cursor.fetchall()
    text = f"👥 **Total Users Profile Count:** `{len(rows)}`\n\n"
    for r in rows[:30]:
      phone_str = f"<code>{r[3]}</code>" if r[3] else "Private"
      res_tag = "👑" if r[4] == 1 else "👤"
      text += f"{res_tag} **{r[1]}** (`{r[0]}`)\n📱 Mobile: {phone_str} | 💰 ₹{r[2]}\n───────────────────\n"
    bot.send_message(call.message.chat.id, text, parse_mode="Markdown")

  elif call.data == "adm_ban_menu":
    if user_id != ADMIN_ID:
      return
    bot.send_message(call.message.chat.id, "Use command format:\n`/ban [ID]` or `/unban [ID]`", parse_mode="Markdown")

  elif call.data == "adm_create_coupon":
    if user_id != ADMIN_ID:
      return
    msg = bot.send_message(call.message.chat.id, "Send format:\n`Code | Amount | Uses`", parse_mode="Markdown")
    bot.register_next_step_handler(msg, process_admin_add_coupon)

  elif call.data == "adm_add_p":
    if user_id != ADMIN_ID:
      return
    msg = bot.send_message(call.message.chat.id, "Send format:\n`Name | PID | Description`", parse_mode="Markdown")
    bot.register_next_step_handler(msg, process_admin_add_product)

  elif call.data == "adm_edit_del_p":
    if user_id != ADMIN_ID:
      return
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT prod_name FROM products")
      prods = cursor.fetchall()
    markup = types.InlineKeyboardMarkup(row_width=1)
    for p in prods:
      markup.add(types.InlineKeyboardButton(f"❌ Terminate {p[0]}", callback_data=f"adm_delprod_{p[0]}"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, "Select product to remove:", reply_markup=markup)
      else:
        bot.edit_message_text("Select product to remove:", call.message.chat.id, call.message.message_id, reply_markup=markup)
    except Exception:
      bot.send_message(call.message.chat.id, "Select product to remove:", reply_markup=markup)

  elif call.data.startswith("adm_delprod_"):
    if user_id != ADMIN_ID:
      return
    p_name = call.data.replace("adm_delprod_", "")
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("DELETE FROM products WHERE prod_name = ?", (p_name,))
      cursor.execute("DELETE FROM plans WHERE prod_name = ?", (p_name,))
      cursor.execute("DELETE FROM reseller_prices WHERE prod_name = ?", (p_name,))
      conn.commit()
    bot.answer_callback_query(call.id, f"Terminated {p_name}", show_alert=True)

  elif call.data == "adm_add_plan":
    if user_id != ADMIN_ID:
      return
    msg = bot.send_message(call.message.chat.id, "Send format:\n`Product Name | 1 DaYs | 150`", parse_mode="Markdown")
    bot.register_next_step_handler(msg, process_admin_add_plan)

  elif call.data == "adm_del_plan":
    if user_id != ADMIN_ID:
      return
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT id, prod_name, duration, price FROM plans")
      plans = cursor.fetchall()
    markup = types.InlineKeyboardMarkup(row_width=1)
    for pl in plans[:20]:
      markup.add(types.InlineKeyboardButton(f"❌ {pl[1]} ({pl[2]}) - ₹{pl[3]}", callback_data=f"adm_delpl_{pl[0]}"))
    
    try:
      if call.message.content_type == 'photo':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, "Select plan to remove:", reply_markup=markup)
      else:
        bot.edit_message_text("Select plan to remove:", call.message.chat.id, call.message.message_id, reply_markup=markup)
    except Exception:
      bot.send_message(call.message.chat.id, "Select plan to remove:", reply_markup=markup)

  elif call.data.startswith("adm_delpl_"):
    if user_id != ADMIN_ID:
      return
    pid = call.data.replace("adm_delpl_", "")
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("DELETE FROM plans WHERE id = ?", (pid,))
      conn.commit()
    bot.answer_callback_query(call.id, "Plan terminated!", show_alert=True)

  elif call.data == "adm_give":
    if user_id != ADMIN_ID:
      return
    bot.send_message(call.message.chat.id, "Use command:\n`/give [User_ID] [Amount]`", parse_mode="Markdown")

  elif call.data == "adm_broadcast":
    if user_id != ADMIN_ID:
      return
    msg = bot.send_message(call.message.chat.id, "📢 Send elite broadcast payload (Text / Photo / Video / Document):")
    bot.register_next_step_handler(msg, process_admin_media_broadcast)

  elif call.data == "back_home":
    send_welcome_refresh(call)


# ==================== STEPS & HANDLERS ====================
def process_custom_gateway_amount(message):
  try:
    amount = int(message.text.strip())
    if amount <= 0:
      bot.reply_to(message, "❌ Topup amount must be greater than zero.")
      return
      
    user_id = message.from_user.id
    api_url = f"https://fampaygateway.site/api/create_order.php?amount={amount}&api_key={GATEWAY_API_KEY}"
    
    response = requests.get(api_url, timeout=10)
    res_data = response.json()
    
    if res_data.get("status") == "success":
      data = res_data["data"]
      order_id = data["order_id"]
      qr_url = data["qr_url"]
      upi_id = data["upi_id"]
      
      with sqlite3.connect("ansh_store_enterprise.db") as conn:
        cursor = conn.cursor()
        cursor.execute("INSERT OR REPLACE INTO gateway_orders (order_id, user_id, amount, status) VALUES (?, ?, ?, ?)", 
                       (order_id, user_id, amount, "PENDING"))
        conn.commit()
      
      markup = types.InlineKeyboardMarkup(row_width=1)
      markup.add(types.InlineKeyboardButton("🔄 Verify Payment Status", callback_data=f"gwcheck_{order_id}"))
      markup.add(types.InlineKeyboardButton("🔙 Main Menu", callback_data="back_home"))
      
      caption = (
          f"🛒 **Secure Payment Gateway v2**\n\n"
          f"🆔 **Order ID:** `{order_id}`\n"
          f"💰 **Amount Due:** ₹{amount}\n"
          f"⚡ **UPI Handle:** `{upi_id}`\n\n"
          f"📱 Scan QR or transfer via UPI app. Once finished, click **'Verify Payment Status'**."
      )
      bot.send_photo(message.chat.id, photo=qr_url, caption=caption, parse_mode="Markdown", reply_markup=markup)
    else:
      bot.reply_to(message, "❌ Gateway Error: Order creation rejected.")
  except ValueError:
    bot.reply_to(message, "❌ Please input a valid numeric amount.")
  except Exception as e:
    bot.reply_to(message, f"⚠️ Exception: {e}")


def process_admin_save_reseller_text(message):
  if message.from_user.id != ADMIN_ID:
    return
  update_setting("reseller_info", message.text)
  bot.reply_to(message, "✅ Reseller info broadcast layout successfully updated!")


def process_admin_save_reseller_price(message):
  if message.from_user.id != ADMIN_ID:
    return
  try:
    parts = message.text.split("|")
    prod_name = parts[0].strip()
    duration = parts[1].strip()
    price = int(parts[2].strip())

    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute(
          "INSERT OR REPLACE INTO reseller_prices (prod_name, duration, price) VALUES (?, ?, ?)",
          (prod_name, duration, price),
      )
      conn.commit()
    bot.reply_to(message, f"✅ Partner Wholesale Price Set!\n📦 **{prod_name}** ({duration}) ➔ **₹{price}**", parse_mode="Markdown")
  except Exception:
    bot.reply_to(message, "❌ Format error! Use format:\n`Product Name | Duration | Price`", parse_mode="Markdown")


def process_admin_add_force_channel(message):
  if message.from_user.id != ADMIN_ID:
    return
  try:
    parts = message.text.split("|")
    ch_uname = parts[0].strip()
    ch_title = parts[1].strip()

    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute(
          "INSERT OR REPLACE INTO force_channels (channel_username, channel_title) VALUES (?, ?)",
          (ch_uname, ch_title),
      )
      conn.commit()
    bot.reply_to(message, "✅ Mandatory force channel successfully linked!")
  except Exception:
    bot.reply_to(message, "❌ Format error! Use: `@ChannelUsername | Channel Title`")


def process_admin_lookup_user(message):
  if message.from_user.id != ADMIN_ID:
    return
  try:
    lookup_id = int(message.text.strip())
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute(
          "SELECT name, balance, joined_date, phone, is_reseller FROM users WHERE user_id = ?",
          (lookup_id,),
      )
      user_data = cursor.fetchone()

      cursor.execute(
          "SELECT product_name, duration, timestamp FROM user_purchases WHERE user_id = ?",
          (lookup_id,),
      )
      purchases = cursor.fetchall()

    if not user_data:
      bot.reply_to(message, "❌ User profile not found in local ledger!")
      return

    phone_str = user_data[3] if user_data[3] else "Private"
    res_status = "Active Partner 👑" if user_data[4] == 1 else "Standard 👤"
    text = (
        f"🔍 <b>USER DOSSIER:</b> `<code>{lookup_id}</code>`\n━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 Name: {user_data[0]}\n📱 Mobile: <code>{phone_str}</code>\n"
        f"💼 Partnership: {res_status}\n💰 Balance: ₹{user_data[1]}\n📅 Joined: {user_data[2]}\n\n"
        f"📦 <b>Vault History ({len(purchases)}):</b>\n"
    )
    for p in purchases[-5:]:
      text += f"• {p[0]} ({p[1]}) - 🕒 {p[2]}\n"

    bot.reply_to(message, text, parse_mode="HTML")
  except Exception:
    bot.reply_to(message, "❌ Invalid User ID token format.")


def process_user_redeem_coupon(message):
  user_id = message.from_user.id
  code = message.text.strip().upper()
  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()
    cursor.execute("SELECT amount, uses_left FROM coupons WHERE code = ?", (code,))
    row = cursor.fetchone()

    if not row or row[1] <= 0:
      conn.close()
      bot.reply_to(message, "❌ Coupon token expired or invalid.")
      return

    amount, uses_left = row
    modify_balance(user_id, amount)
    log_history(user_id, f"Redeemed promotional token {code} for ₹{amount}")

    if uses_left - 1 <= 0:
      cursor.execute("DELETE FROM coupons WHERE code = ?", (code,))
    else:
      cursor.execute("UPDATE coupons SET uses_left = uses_left - 1 WHERE code = ?", (code,))
    conn.commit()

  bot.reply_to(message, f"🎉 **Coupon Accepted!** ₹{amount} added to secure wallet.")


def process_admin_add_coupon(message):
  if message.from_user.id != ADMIN_ID:
    return
  try:
    parts = message.text.split("|")
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute(
          "INSERT OR REPLACE INTO coupons (code, amount, uses_left) VALUES (?, ?, ?)",
          (parts[0].strip().upper(), int(parts[1].strip()), int(parts[2].strip())),
      )
      conn.commit()
    bot.reply_to(message, "✅ Promotional coupon generated!")
  except Exception:
    bot.reply_to(message, "❌ Format error! Use: `Code | Amount | Uses`")


def process_admin_add_product(message):
  if message.from_user.id != ADMIN_ID:
    return
  try:
    parts = message.text.split("|")
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute(
          "INSERT OR REPLACE INTO products (prod_name, pid, description) VALUES (?, ?, ?)",
          (parts[0].strip(), parts[1].strip(), parts[2].strip()),
      )
      conn.commit()
    bot.reply_to(message, "✅ Product module registered!")
  except Exception:
    bot.reply_to(message, "❌ Format error! Use: `Name | PID | Description`")


def process_admin_add_plan(message):
  if message.from_user.id != ADMIN_ID:
    return
  try:
    parts = message.text.split("|")
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("INSERT INTO plans (prod_name, duration, price) VALUES (?, ?, ?)", (parts[0].strip(), parts[1].strip(), int(parts[2].strip())))
      conn.commit()
    bot.reply_to(message, "✅ Plan mapping added successfully!")
  except Exception:
    bot.reply_to(message, "❌ Format error! Use: `Product Name | 1 DaYs | 150`")


@bot.message_handler(commands=["ban"])
def command_ban_user(message):
  if message.from_user.id != ADMIN_ID:
    return
  try:
    tid = int(message.text.split()[1])
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("INSERT OR IGNORE INTO blocked_users (user_id) VALUES (?)", (tid,))
      conn.commit()
    bot.reply_to(message, f"✅ User `<code>{tid}</code>` sanctioned/banned.", parse_mode="Markdown")
  except Exception:
    bot.reply_to(message, "❌ Use syntax: `/ban [ID]`", parse_mode="Markdown")


@bot.message_handler(commands=["unban"])
def command_unban_user(message):
  if message.from_user.id != ADMIN_ID:
    return
  try:
    tid = int(message.text.split()[1])
    with sqlite3.connect("ansh_store_enterprise.db") as conn:
      cursor = conn.cursor()
      cursor.execute("DELETE FROM blocked_users WHERE user_id = ?", (tid,))
      conn.commit()
    bot.reply_to(message, f"✅ User `<code>{tid}</code>` unsanctioned.", parse_mode="Markdown")
  except Exception:
    bot.reply_to(message, "❌ Use syntax: `/unban [ID]`", parse_mode="Markdown")


@bot.message_handler(commands=["give"])
def command_give_balance(message):
  if message.from_user.id != ADMIN_ID:
    return
  try:
    parts = message.text.split()
    modify_balance(int(parts[1]), int(parts[2]))
    bot.reply_to(message, "✅ Wallet credit successfully applied.")
  except Exception:
    bot.reply_to(message, "❌ Use syntax: `/give [ID] [Amount]`", parse_mode="Markdown")


def process_admin_media_broadcast(message):
  if message.from_user.id != ADMIN_ID:
    return
  with sqlite3.connect("ansh_store_enterprise.db") as conn:
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM users")
    users = cursor.fetchall()

  progress_msg = bot.reply_to(message, "⏳ Elite broadcast dissemination initiated...")
  count = 0
  total_users = len(users)

  for idx, u in enumerate(users):
    try:
      if message.content_type == "text":
        bot.send_message(u[0], f"📢 **•:**\n\n{message.text}", parse_mode="Markdown")
      elif message.content_type == "photo":
        bot.send_photo(u[0], message.photo[-1].file_id, caption=message.caption or "", parse_mode="Markdown")
      elif message.content_type == "video":
        bot.send_video(u[0], message.video.file_id, caption=message.caption or "", parse_mode="Markdown")
      elif message.content_type == "document":
        bot.send_document(u[0], message.document.file_id, caption=message.caption or "", parse_mode="Markdown")
      count += 1
    except Exception:
      pass

    if idx > 0 and idx % 50 == 0:
      try:
        bot.edit_message_text(f"⏳ Broadcast in progress...\nDelivered: {idx}/{total_users}", chat_id=message.chat.id, message_id=progress_msg.message_id)
      except Exception:
        pass

  bot.edit_message_text(f"✅ Broadcast successfully delivered to {count}/{total_users} active profiles!", chat_id=message.chat.id, message_id=progress_msg.message_id)


def send_welcome_refresh(call):
  user_id = call.from_user.id
  user_name = call.message.chat.first_name if hasattr(call, 'message') and call.message else "User"
  balance = get_user_balance(user_id)
  store_title = get_setting("store_title")
  proof_url = get_setting("proof_channel") or "https://t.me/Anshbhaiproofs"
  badge = "👑 Elite Reseller" if is_user_reseller(user_id) else "🛡️ Standard Member"

  text = (
      f"💎 <b>⚡ {store_title} ⚡</b> 💎\n━━━━━━━━━━━━━━━━━━━━━\n"
      f"👋 Welcome back, <b>{user_name}</b>!\n\n"
      f"👤 <b>User ID:</b> <code>{user_id}</code>\n"
      f"🏷️ <b>Tier:</b> {badge}\n"
      f"💰 <b>Wallet Balance:</b> ₹{balance}\n━━━━━━━━━━━━━━━━━━━━━"
  )
  markup = types.InlineKeyboardMarkup(row_width=2)
  markup.add(
      types.InlineKeyboardButton("⚡ 🛒 Shop Keys", callback_data="shop_key"),
      types.InlineKeyboardButton("👤 My Profile", callback_data="my_profile"),
      types.InlineKeyboardButton("📦 Orders Vault", callback_data="my_orders"),
      types.InlineKeyboardButton("💳 Add Balance", callback_data="add_balance"),
      types.InlineKeyboardButton("📊 History", callback_data="all_history"),
      types.InlineKeyboardButton("🎟️ Redeem Code", callback_data="redeem_menu"),
      types.InlineKeyboardButton("💬 Support Ticket", callback_data="support_ticket"),
      types.InlineKeyboardButton("💼 Become Reseller", callback_data="wanna_reseller"),
      types.InlineKeyboardButton("📈 Live Proofs ↗", url=proof_url),
      types.InlineKeyboardButton("🎰 Daily Lucky Spin", callback_data="lucky_spin"),
      types.InlineKeyboardButton("🎁 Refer & Earn", callback_data="referral"),
  )
  if user_id == ADMIN_ID:
    markup.add(types.InlineKeyboardButton("⚙️ Admin Control Panel", callback_data="admin_panel"))

  try:
    if call.message.content_type == 'photo':
      bot.delete_message(call.message.chat.id, call.message.message_id)
      bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)
    else:
      bot.edit_message_text(
          text,
          call.message.chat.id,
          call.message.message_id,
          parse_mode="HTML",
          reply_markup=markup,
      )
  except Exception:
    try:
      bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup)
    except Exception:
      pass


print("ANSHXMODZYT BOT IS RUNNING 🏃")
bot.infinity_polling()
